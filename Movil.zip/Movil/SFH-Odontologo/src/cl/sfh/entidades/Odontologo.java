package cl.sfh.entidades;

public class Odontologo
{
	
}
