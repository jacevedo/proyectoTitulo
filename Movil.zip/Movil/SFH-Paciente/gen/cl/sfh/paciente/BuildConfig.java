/** Automatically generated file. DO NOT MODIFY */
package cl.sfh.paciente;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}